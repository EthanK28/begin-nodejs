var foo = require('./foo');

// create a new object
var obj = foo();

// use it
console.log(obj.something); // 123
