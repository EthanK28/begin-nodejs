module.exports = function () {
    console.log('a function in file foo');
};