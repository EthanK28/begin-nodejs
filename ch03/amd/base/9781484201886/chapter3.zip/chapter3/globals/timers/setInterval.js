setInterval(function () {
    console.log('second passed');
}, 1000);