var foo = require('./foo');
var bar = require('./bar');

foo();
bar.log();